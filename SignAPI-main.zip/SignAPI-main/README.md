# SignAPI
各平台请求签名API实现
